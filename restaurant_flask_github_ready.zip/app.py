from flask import Flask, render_template, request, redirect, session, url_for
import json

app = Flask(__name__)
app.secret_key = 'your_secret_key'

def get_user_from_db(username, password):
    with open('users.json', 'r') as f:
        return json.load(f)

def load_dashboard_data(branch_name=None):
    with open('dashboard_data.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data if branch_name is None else data.get(branch_name, [])

@app.route('/', methods=['GET', 'POST'])

import sqlite3

def get_user_from_db(username, password):
    conn = sqlite3.connect('restaurant_system.db')
    cursor = conn.cursor()
    cursor.execute("SELECT username, role, branch_id FROM users WHERE username=? AND password=?", (username, password))
    result = cursor.fetchone()
    conn.close()
    return result

if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = get_user_from_db(username, password)

        if user:
            session['username'] = user[0]
            session['role'] = user[1]
            session['branch_id'] = user[2]

            if user[1] == 'admin':
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error='اسم المستخدم أو كلمة المرور غير صحيحة')

    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'branch' not in session or session['role'] != 'branch':
        return redirect(url_for('login'))
    data = load_dashboard_data(session['branch'])
    return render_template('dashboard.html', branch=session['branch'], data=data)

@app.route('/admin')
def admin_dashboard():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    
    data = load_dashboard_data()
    branches = []
    total_orders = total_revenue = total_cost = total_profit = 0
    
    for name, entries in data.items():
        orders = sum(e['quantity'] for e in entries)
        revenue = sum(e['quantity'] * e['selling_price'] for e in entries)
        cost = sum(e['quantity'] * e['cost_price'] for e in entries)
        profit = revenue - cost
        margin = (profit / revenue * 100) if revenue else 0
        
        branches.append({
            'name': name,
            'orders': orders,
            'revenue': revenue,
            'cost': cost,
            'profit': profit,
            'margin': margin
        })
        
        total_orders += orders
        total_revenue += revenue
        total_cost += cost
        total_profit += profit

    avg_margin = (total_profit / total_revenue * 100) if total_revenue else 0
    
    return render_template("admin_dashboard.html", 
                           branches=branches,
                           total_orders=total_orders,
                           total_revenue=total_revenue,
                           total_cost=total_cost,
                           total_profit=total_profit,
                           avg_margin=avg_margin)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.route('/recipes', methods=['GET'])
def recipes():
    if 'role' not in session or session['role'] != 'branch':
        return redirect(url_for('login'))

    branch_id = session['branch_id']
    conn = sqlite3.connect('restaurant_system.db')
    cursor = conn.cursor()

    # جلب الوصفات الخاصة بالفرع
    cursor.execute("SELECT id, name, selling_price FROM recipes WHERE branch_id=?", (branch_id,))
    recipes_raw = cursor.fetchall()

    recipes = []
    for recipe_id, name, selling_price in recipes_raw:
        # حساب تكلفة الوصفة
        cursor.execute("""
            SELECT ri.quantity_used, i.unit_price
            FROM recipe_ingredients ri
            JOIN ingredients i ON ri.ingredient_id = i.id
            WHERE ri.recipe_id=? AND i.branch_id=?
        """, (recipe_id, branch_id))
        cost_rows = cursor.fetchall()

        total_cost = sum(qty * price for qty, price in cost_rows)
        margin = ((selling_price - total_cost) / selling_price * 100) if selling_price else 0

        recipes.append({
            "name": name,
            "price": selling_price,
            "cost": total_cost,
            "margin": margin
        })

    conn.close()
    return render_template("recipes.html", recipes=recipes)


if __name__ == '__main__':
    app.run(debug=True)

from flask import Flask, render_template, request, redirect, session, url_for, flash
import json, os
import pandas as pd
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'xlsx'}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        branch_name = request.form['branch_name']
        file = request.files['excel_file']
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # قراءة البيانات من الإكسل
            try:
                df_sales = pd.read_excel(filepath, sheet_name="Sales")
                df_recipes = pd.read_excel(filepath, sheet_name="Recipes")
                df_ingredients = pd.read_excel(filepath, sheet_name="Ingredients")
                df_recipe_ingredients = pd.read_excel(filepath, sheet_name="Recipe_Ingredients")

                # تجهيز البيانات
                dashboard_data_path = 'dashboard_data.json'
                if os.path.exists(dashboard_data_path):
                    with open(dashboard_data_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                else:
                    data = {}

                # دمج البيانات للفرع الجديد
                branch_data = []
                for _, row in df_sales.iterrows():
                    recipe = df_recipes[df_recipes["Recipe_ID"] == row["Recipe_ID"]].iloc[0]
                    cost_rows = df_recipe_ingredients[df_recipe_ingredients["Recipe_ID"] == row["Recipe_ID"]]
                    total_cost = 0
                    for _, r in cost_rows.iterrows():
                        ingredient = df_ingredients[df_ingredients["Ingredient_ID"] == r["Ingredient_ID"]].iloc[0]
                        total_cost += float(ingredient["Unit_Price"]) * float(r["Quantity_Used"])
                    branch_data.append({
                        "date": str(row["Date"]),
                        "item": recipe["Recipe_Name"],
                        "quantity": int(row["Quantity_Sold"]),
                        "selling_price": float(recipe["Selling_Price"]),
                        "cost_price": total_cost
                    })

                data[branch_name] = branch_data

                with open(dashboard_data_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)

                return f"تم رفع البيانات بنجاح لفرع {branch_name}"
            except Exception as e:
                return f"خطأ أثناء معالجة الملف: {e}"
        else:
            return "الملف غير صالح. يجب أن يكون بصيغة .xlsx"
    
    return render_template("upload.html")


@app.route('/recipes', methods=['GET'])
def recipes():
    if 'role' not in session or session['role'] != 'branch':
        return redirect(url_for('login'))

    branch_id = session['branch_id']
    conn = sqlite3.connect('restaurant_system.db')
    cursor = conn.cursor()

    # جلب الوصفات الخاصة بالفرع
    cursor.execute("SELECT id, name, selling_price FROM recipes WHERE branch_id=?", (branch_id,))
    recipes_raw = cursor.fetchall()

    recipes = []
    for recipe_id, name, selling_price in recipes_raw:
        # حساب تكلفة الوصفة
        cursor.execute("""
            SELECT ri.quantity_used, i.unit_price
            FROM recipe_ingredients ri
            JOIN ingredients i ON ri.ingredient_id = i.id
            WHERE ri.recipe_id=? AND i.branch_id=?
        """, (recipe_id, branch_id))
        cost_rows = cursor.fetchall()

        total_cost = sum(qty * price for qty, price in cost_rows)
        margin = ((selling_price - total_cost) / selling_price * 100) if selling_price else 0

        recipes.append({
            "name": name,
            "price": selling_price,
            "cost": total_cost,
            "margin": margin
        })

    conn.close()
    return render_template("recipes.html", recipes=recipes)
